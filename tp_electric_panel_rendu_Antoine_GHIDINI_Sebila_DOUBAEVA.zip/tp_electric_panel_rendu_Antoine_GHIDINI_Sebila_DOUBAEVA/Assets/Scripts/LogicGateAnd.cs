using UnityEngine;

public class LogicGateAnd : LogicGateBase
{


    public override bool UseGate()
    {
        return connectionPins[0].IsOn && connectionPins[1].IsOn;
    }
}
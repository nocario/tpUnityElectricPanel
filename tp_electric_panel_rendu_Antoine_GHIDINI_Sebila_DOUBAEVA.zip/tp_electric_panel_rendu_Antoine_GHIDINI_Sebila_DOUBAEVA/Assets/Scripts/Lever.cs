using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lever : MonoBehaviour
{
    public bool isOn = false;
    Animator animator;
    void Start () {
        animator = GetComponent<Animator>();
    }
    
    void Update() {
        animator.SetBool("IsOn", isOn);
        //https://www.c-sharpcorner.com/article/how-to-detect-mouse-click-or-touch-on-a-gameobject-using-c-sharp-script-in-unity3d/
        if (Input.GetMouseButtonDown(0)) {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);  
            RaycastHit hit;  
            if (Physics.Raycast(ray, out hit)) {  
            //Select stage    
            if (hit.transform.name == transform.name) {  
                isOn = !isOn;
            }  
        }  
        }
    }
}

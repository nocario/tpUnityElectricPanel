using UnityEngine;

public class LogicGateDirect : LogicGateBase
{
    public override bool UseGate()
    {
        return connectionPins[0].IsOn;
    }
}

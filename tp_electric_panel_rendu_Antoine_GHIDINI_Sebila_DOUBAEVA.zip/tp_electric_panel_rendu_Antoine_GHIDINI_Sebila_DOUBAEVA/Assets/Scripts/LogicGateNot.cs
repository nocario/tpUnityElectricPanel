using UnityEngine;

public class LogicGateNot : LogicGateBase
{
    public override bool UseGate()
    {
        return !connectionPins[0].IsOn;
    }
}

using UnityEngine;


public class LogicGateOr : LogicGateBase
{

    public override bool UseGate()
    {
        return connectionPins[0].IsOn || connectionPins[1].IsOn;
    }
}
